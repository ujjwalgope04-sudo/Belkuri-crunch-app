# -*- coding: utf-8 -*-
"""
Offline news data for BELKURI CRUNCH app.
Replace / add articles here manually. No internet needed.
Each article: title, category, summary, content, date
"""

NEWS_DATA = [
    {
        "title": "Belkuri Village Sees Record Harvest This Season",
        "category": "Top News",
        "date": "27 Sep 2026",
        "summary": "Local farmers report the best harvest in a decade thanks to timely rains.",
        "content": (
            "Farmers across the Belkuri region are celebrating one of the "
            "best harvest seasons in recent memory. Officials credit timely "
            "monsoon rains and improved irrigation support for the boost in "
            "yield. Local markets are expected to see lower prices on staple "
            "crops in the coming weeks as supply increases."
        ),
    },
    {
        "title": "New Community Health Camp Announced for Next Week",
        "category": "Top News",
        "date": "26 Sep 2026",
        "summary": "Free health checkups and medicines to be offered to residents.",
        "content": (
            "A free health camp will be organized next week, offering basic "
            "checkups, eye tests, and free medicines to residents. Volunteers "
            "and local doctors are expected to participate. Organizers urge "
            "residents to bring any previous medical records."
        ),
    },
    {
        "title": "State Assembly Passes New Infrastructure Bill",
        "category": "Politics",
        "date": "25 Sep 2026",
        "summary": "The bill focuses on rural road connectivity and water supply.",
        "content": (
            "The state assembly has passed a new infrastructure bill aimed at "
            "improving rural road connectivity and water supply systems. "
            "Opposition leaders welcomed the move but raised questions about "
            "the funding timeline. The bill is expected to be implemented in "
            "phases over the next three years."
        ),
    },
    {
        "title": "Local Cricket Team Wins Regional Championship",
        "category": "Sports",
        "date": "24 Sep 2026",
        "summary": "The team defeated defending champions in a thrilling final.",
        "content": (
            "In a nail-biting finish, the local cricket team clinched the "
            "regional championship title, defeating the two-time defending "
            "champions by 4 wickets. The man of the match award went to the "
            "young all-rounder who scored a crucial half-century."
        ),
    },
    {
        "title": "Youth Football League Kicks Off This Weekend",
        "category": "Sports",
        "date": "23 Sep 2026",
        "summary": "16 teams from nearby villages will compete this season.",
        "content": (
            "The annual youth football league begins this weekend with 16 "
            "teams from surrounding villages competing for the trophy. "
            "Organizers say this year's tournament has the highest number of "
            "participants yet."
        ),
    },
    {
        "title": "Local Theatre Group Stages Award-Winning Play",
        "category": "Entertainment",
        "date": "22 Sep 2026",
        "summary": "The group's latest production has received praise from critics.",
        "content": (
            "A local theatre group has staged a critically acclaimed play "
            "this week, drawing large crowds. The production, written and "
            "directed by local artists, tells the story of a family's "
            "journey through changing times."
        ),
    },
    {
        "title": "Small Businesses Report Growth Ahead of Festive Season",
        "category": "Business",
        "date": "21 Sep 2026",
        "summary": "Local shop owners expect a strong festive shopping season.",
        "content": (
            "Small business owners in the area are optimistic about the "
            "upcoming festive season, reporting early signs of increased "
            "customer footfall. Many shops have begun stocking up on "
            "seasonal goods in anticipation of higher demand."
        ),
    },
    {
        "title": "Farmers Cooperative Launches Direct-to-Market App",
        "category": "Technology",
        "date": "20 Sep 2026",
        "summary": "The app aims to connect farmers directly with buyers.",
        "content": (
            "A local farmers cooperative has launched a mobile app that "
            "connects farmers directly with buyers, cutting out middlemen. "
            "Early adopters say the app has already helped them get better "
            "prices for their produce."
        ),
    },
]

CATEGORIES = ["Top News", "Politics", "Sports", "Entertainment", "Business", "Technology"]


def get_all_articles():
    """Static built-in articles + owner-added articles from the Admin Panel."""
    from storage import get_custom_articles
    return get_custom_articles() + NEWS_DATA


def get_articles_by_category(category):
    all_articles = get_all_articles()
    if category == "Top News" or category == "All":
        return all_articles
    return [a for a in all_articles if a["category"] == category]
