# Belkuri Crunch — Android App

This repository contains the Belkuri Crunch Kivy Android project extracted from the supplied build notebook.

## Automatic APK build with GitHub

1. Create a new GitHub repository.
2. Upload all files from this folder to the repository root.
3. Use the `main` branch (or `master`).
4. Open **Actions** in GitHub.
5. The **Build Android APK** workflow runs automatically after a push.
6. When it finishes, open the workflow run and download the **belkuricrunch-apk** artifact.

You can also start a build manually from **Actions → Build Android APK → Run workflow**.

The workflow uses Buildozer's GitHub Action to build the existing Kivy application. The first Android build can take a while because Android build dependencies are downloaded and prepared.

## App source

The project includes the notebook's generated:
- `main.py`
- `news_data.py`
- `storage.py`
- `belkuricrunch.kv`
- `buildozer.spec`
- `icon.png`
- `logo.png`

No conversion to another UI framework was performed; the supplied Kivy app is packaged directly for Android.

## Local build

```bash
buildozer android debug
```

The APK is written to `bin/`.
